/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onoh;

/**
 *
 * @author rishu
 */
public class Sender {
    
    String uname, upwd;
    
    public Sender()
    {
        uname = "patchief058@gmail.com";
        upwd = "iamchiefpat";
    }
    
}
