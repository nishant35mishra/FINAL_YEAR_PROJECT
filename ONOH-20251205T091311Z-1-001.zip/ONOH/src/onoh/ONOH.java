/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onoh;

/**
 *
 * @author rishu
 */
public class ONOH {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ONOH_Home obhome = new ONOH_Home();
        obhome.setLocationRelativeTo(null);
        obhome.setVisible(true);
        
    }
    
}
